"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { OrganizacaoClientShell } from "@/components/organizacao-client-shell";
import { supabaseBrowser } from "@/lib/supabase-browser";

type Person = {
  id: string;
  full_name: string;
  email: string | null;
  whatsapp: string | null;
  active: boolean;
};

type Membership = {
  id: string;
  person_id: string;
  status: string | null;
  active: boolean | null;
  agenda_viva_profile: Record<string, unknown> | null;
};

type ValidationRequest = {
  id: string;
  person_id: string;
  status: string | null;
  summary: Record<string, unknown> | null;
  created_at?: string | null;
  updated_at?: string | null;
};

type Payload = {
  people: Person[];
  memberships: Membership[];
  validationRequests?: ValidationRequest[];
  error?: string;
  whatsappUrl?: string;
};

type ValidationItem = {
  membership: Membership & { status: string };
  request: ValidationRequest | null;
  person: Person;
};

function asText(value: unknown) {
  return typeof value === "string" ? value : "";
}

function clientLoginUrl() {
  if (typeof window === "undefined") return "/solucoes/organizacao-em-harmonia/login";
  const returnTo = `${window.location.pathname}${window.location.search}${window.location.hash}`;
  return `/solucoes/organizacao-em-harmonia/login?returnTo=${encodeURIComponent(returnTo)}`;
}

function selectedLabels(value: unknown) {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => {
      if (!item || typeof item !== "object") return "";
      const label = (item as { label?: unknown }).label;
      return typeof label === "string" ? label : "";
    })
    .filter(Boolean);
}

export default function ValidacoesPrimeiroAcessoPage() {
  const [payload, setPayload] = useState<Payload | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    const { data: sessionData } = await supabaseBrowser.auth.getSession();
    const token = sessionData.session?.access_token;
    if (!token) {
      window.location.replace(clientLoginUrl());
      return;
    }

    const response = await fetch("/api/organizacao-em-harmonia/cliente/base-unica", {
      headers: { Authorization: `Bearer ${token}` },
    });
    const result = (await response.json()) as Payload;
    if (!response.ok) throw new Error(result.error || "Não foi possível carregar validações.");
    setPayload(result);
  }, []);

  useEffect(() => {
    let active = true;
    const timer = window.setTimeout(() => {
      load()
        .catch((err) => {
          if (active) setError(err instanceof Error ? err.message : "Erro ao carregar validações.");
        })
        .finally(() => {
          if (active) setLoading(false);
        });
    }, 0);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [load]);

  const validations = useMemo(() => {
    const people = payload?.people ?? [];
    const requests = payload?.validationRequests ?? [];
    const requestByPerson = new Map(requests.map((request) => [request.person_id, request]));

    return (payload?.memberships ?? [])
      .flatMap<ValidationItem>((membership) => {
        const profile = membership.agenda_viva_profile ?? {};
        const request = requestByPerson.get(membership.person_id) ?? null;
        const cameFromFirstAccess =
          profile.source === "primeiro_acesso_filho_corrente" ||
          Boolean(profile.submittedAt) ||
          Boolean(profile.validationStatus) ||
          Boolean(request);

        if (!cameFromFirstAccess) return [];

        const person = people.find((personItem) => personItem.id === membership.person_id);
        if (!person) return [];

        const status = request?.status || asText(profile.validationStatus) || membership.status || "pendente_primeiro_acesso";

        return [
          {
            membership: { ...membership, status },
            request,
            person,
          },
        ];
      })
      .sort((a, b) => {
        const order: Record<string, number> = {
          pendente_validacao: 0,
          pendente_primeiro_acesso: 1,
          ajuste_solicitado: 2,
          ativo: 3,
          inativo: 4,
        };
        const aStatus = a.membership.status || "pendente_primeiro_acesso";
        const bStatus = b.membership.status || "pendente_primeiro_acesso";
        return (order[aStatus] ?? 9) - (order[bStatus] ?? 9);
      });
  }, [payload?.memberships, payload?.people, payload?.validationRequests]);

  async function decide(personId: string, action: "approveAccess" | "requestAccessAdjustment" | "deleteAccessValidation") {
    if (action === "deleteAccessValidation") {
      const confirmed = window.confirm("Excluir este pedido de validação? Isso remove o cadastro pendente para que o teste possa ser repetido.");
      if (!confirmed) return;
    }
    const reviewNotes = action === "requestAccessAdjustment" ? window.prompt("Informe o ajuste/reprovação ao Filho da Corrente:") || "" : "";
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const { data: sessionData } = await supabaseBrowser.auth.getSession();
      const token = sessionData.session?.access_token;
      if (!token) throw new Error("Sessão expirada.");
      const response = await fetch("/api/organizacao-em-harmonia/cliente/base-unica", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action, personId, reviewNotes }),
      });
      const result = (await response.json()) as Payload & { error?: string };
      if (!response.ok) throw new Error(result.error || "Não foi possível atualizar a validação.");
      setPayload(result);
      if (result.whatsappUrl && action !== "deleteAccessValidation") {
        window.setTimeout(() => {
          const opened = window.open(result.whatsappUrl, "_blank", "noopener,noreferrer");
          if (!opened) window.location.href = result.whatsappUrl || "";
        }, 150);
      }
      setMessage(action === "approveAccess" ? "Acesso liberado. O WhatsApp do Filho da Corrente foi aberto com a mensagem de confirmação." : action === "deleteAccessValidation" ? "Pedido de validação excluído." : "Ajuste solicitado. O WhatsApp do Filho da Corrente foi aberto com a orientação.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao atualizar validação.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <OrganizacaoClientShell title="Validações do Primeiro Acesso" description="Aprove cadastros de Filhos da Corrente, solicite ajustes e simule o acesso antes de liberar o uso real.">
      {loading && <p className="rounded-3xl bg-white p-5 shadow ring-1 ring-slate-100">Carregando validações...</p>}
      {error && <p className="rounded-3xl bg-red-50 p-5 font-bold text-red-700 ring-1 ring-red-100">{error}</p>}
      {message && <p className="rounded-3xl bg-emerald-50 p-5 font-bold text-emerald-800 ring-1 ring-emerald-100">{message}</p>}

      {!loading && (
        <section className="grid gap-4">
          {validations.map(({ membership, person }) => {
            const profile = membership.agenda_viva_profile ?? {};
            const functionLabels = selectedLabels(profile.selectedFunctions);
            const agendaLabels = selectedLabels(profile.selectedAgenda);
            return (
              <article key={membership.id} className="rounded-[2rem] bg-white p-5 shadow ring-1 ring-slate-100">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.24em] text-[#2F6B43]">{membership.status === "ativo" ? "Acesso aprovado" : membership.status === "ajuste_solicitado" ? "Ajuste solicitado" : membership.status === "pendente_primeiro_acesso" ? "Aguardando primeiro acesso" : "Aguardando validação"}</p>
                    <h2 className="mt-1 text-2xl font-black text-[#00334E]">{person?.full_name}</h2>
                    <p className="mt-2 text-sm leading-6 text-slate-600">{person?.whatsapp || "WhatsApp não informado"} · {person?.email || "E-mail não informado"}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Link href={`/solucoes/organizacao-em-harmonia/cliente/simular-acesso/${person?.id}`} className="rounded-xl bg-slate-100 px-4 py-2 text-sm font-black text-[#00334E]">Simular acesso</Link>
                    {membership.status !== "ativo" && (
                      <button disabled={saving} type="button" onClick={() => person?.id && decide(person.id, "approveAccess")} className="rounded-xl bg-[#31C16B] px-4 py-2 text-sm font-black text-[#00334E] disabled:opacity-60">Aprovar</button>
                    )}
                    {membership.status === "ativo" ? (
                      <button disabled={saving} type="button" onClick={() => person?.id && decide(person.id, "requestAccessAdjustment")} className="rounded-xl bg-amber-50 px-4 py-2 text-sm font-black text-amber-900 disabled:opacity-60">Reprovar / voltar para ajuste</button>
                    ) : (
                      <button disabled={saving} type="button" onClick={() => person?.id && decide(person.id, "requestAccessAdjustment")} className="rounded-xl bg-amber-50 px-4 py-2 text-sm font-black text-amber-900 disabled:opacity-60">Pedir ajuste</button>
                    )}
                    <button disabled={saving} type="button" onClick={() => person?.id && decide(person.id, "deleteAccessValidation")} className="rounded-xl bg-red-50 px-4 py-2 text-sm font-black text-red-700 disabled:opacity-60">Excluir pedido</button>
                  </div>
                </div>
                <div className="mt-4 grid gap-3 md:grid-cols-2">
                  <div className="rounded-2xl bg-[#F7FAF2] p-4 ring-1 ring-[#123D2C]/10">
                    <p className="font-black text-[#00334E]">Funções</p>
                    <p className="mt-2 text-sm leading-6 text-slate-600">{functionLabels.length ? functionLabels.join(" • ") : "Somente Filho da Corrente"}</p>
                  </div>
                  <div className="rounded-2xl bg-[#F7FAF2] p-4 ring-1 ring-[#123D2C]/10">
                    <p className="font-black text-[#00334E]">Agenda</p>
                    <div className="mt-2 grid gap-2 text-sm leading-6 text-slate-600">
                      {agendaLabels.length ? agendaLabels.map((label) => <p key={label} className="rounded-xl bg-white/70 p-2 ring-1 ring-[#123D2C]/10">{label}</p>) : <p>Sem agenda selecionada</p>}
                    </div>
                  </div>
                </div>
                {asText(profile.submittedAt) && <p className="mt-3 text-xs font-semibold text-slate-500">Enviado em: {new Date(asText(profile.submittedAt)).toLocaleString("pt-BR")}</p>}
              </article>
            );
          })}
          {validations.length === 0 && <p className="rounded-3xl bg-white p-5 font-bold text-slate-500 shadow ring-1 ring-slate-100">Nenhum pedido de validação encontrado.</p>}
        </section>
      )}
    </OrganizacaoClientShell>
  );
}
